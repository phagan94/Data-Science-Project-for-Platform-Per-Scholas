# MapReduce_Java_VoteCount

This is a tutorial on a sample reduce program in Java, implemented in Hortonworks hadoop HDP sandbox.


The tutorila video is uploaded in the URL:  https://youtu.be/4fzhAmnWlrg

