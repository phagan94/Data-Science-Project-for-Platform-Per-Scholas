// Class Name: copyArray.java
// Package: CopyArray
// Author: Patrick Hagan
// Description: Copy array of 10 random numbers to another array
// Date: July 18, 2018
// *******************************************************************************************************
package CopyArray;

public class copyArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array1 = {10, 3, 5, 8, 2, 4, 9, 6, 8, 8};
		int[] array2 = new int[10];
		int[] array3 = new int[10];
				
		// copy array1 to array2 by individual cells
		if (array2.length >= array1.length) {
			
		   // display values in array1
		   System.out.println("array1: ");	
	       for (int i = 0; i < array1.length; i++) {
	    	   System.out.print(array1[i] + " ");
	       }
	       
	       // display values in array2
	       System.out.println("\n" + "array2: ");
	       for (int i = 0; i < array1.length; i++) {
	    	   System.out.print(array1[i] + " ");
	       }
		}
		
		// copy array1 to array3 by whole assignment
		array3 = array1;
		
		// display values in array3
		System.out.println("\n" + "array3: ");
	    for (int i = 0; i < array3.length; i++) {
	       System.out.print(array3[i] + " ");
	    }
	}
}
