// Class Name: howManyTimes.java
// Package: HowManyTimes
// Author: Patrick Hagan
// Description: Search for any many times user's choice appears in array
// Date: July 18, 2018
// *******************************************************************************************************
package HowManyTimes;

import java.util.*;

public class howManyTimes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array1 = {10, 3, 5, 8, 2, 4, 9, 6, 8, 8};
		int count = 0;
		String display = " ";
		
		// display values in array1
		System.out.println("array to search and count number of selected value: ");	
	    for (int i = 0; i < array1.length; i++) {
	       System.out.print(array1[i] + " ");
	    }
		
	    System.out.println("\n" + "Please select value to search for: ");
		Scanner sc = new Scanner(System.in);
		int searchInt = sc.nextInt();
		
		// search for selected value in array
		for (int i = 0; i < array1.length; i++) {
			if (array1[i] == searchInt) {
				count++;
			}
		}
		
		// after loop, close scanner
	       sc.close();
		
		if (count == 1) {
			display = " time."; 
		}
		else {
			display = " times.";
	    }
		
		System.out.println("\n" + "The search value is: " + searchInt + " was found: " +
		  count + display);
	}
}
