// Class Name: commaSeparatedValues.java
// Package: commaSeparatedValues
// Author: Patrick Hagan
// Description: Put multiple words into a String array
// Date: July 18, 2018
// *******************************************************************************************************
package CommaSeparatedValues;

import java.util.*;

public class commaSeparatedValues {
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> list = new ArrayList<String>();
		String str = " ";
		
		// add test values to ArrayList to test why last System.out not working
		list.add("First");
		list.add("Second");
		list.add("Third");
		// iterate over list using for each
		for (String s : list) {
			System.out.println("Initial vales in list: " + s);
		}
		
	    System.out.println("Please enter a bunch of words separated by commas: ");
				
        // read from input stream; can read from file
        Scanner sc = new Scanner(System.in);
        sc.useDelimiter(",");
               
/*      // get users words
 *      // Note: This was the original code I had and it keep hanging
 *      // and would not go past the end of the while. I am guessing that 
 *      // scanner was looking for more input. Did it for next and nextLine 
        System.out.println("Before while");
        while(sc.hasNextLine()) {
        	//read single line, put in string
        	str = sc.next();
        	System.out.println("Input string: " + str);
        	// add str to list
        	list.add(str);
        	System.out.println("List value in: " + list); 
        }	*/
        
	    str = sc.nextLine();
	    for (String s : str.split(",")) {
	    	System.out.println("Input string: " + s);
	    	// add string s to list
	    	list.add(s);
	    	System.out.println("List value in: " + list);
	    }
	    
        // after loop, close scanner
        sc.close();     
        
        System.out.println("After while");
        for(String s: list){
            System.out.println("ArrayList: " + s);
        }
        
   	}
}
