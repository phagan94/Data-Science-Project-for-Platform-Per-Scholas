// Class Name: findValueArray.java
// Package: FindValueArray
// Author: Patrick Hagan
// Description: Search array using user input 
// Date: July 18, 2018
// *******************************************************************************************************
package FindValueArray;

import java.util.*;

public class findValueArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array1 = {10, 3, 5, 8, 2, 4, 9, 6, 8, 8};
		
		// display values in array1
		System.out.println("array to search: ");	
	    for (int i = 0; i < array1.length; i++) {
	       System.out.print(array1[i] + " ");
	    }
		
		System.out.println("\n" + "Please select value to search for: ");
		Scanner sc = new Scanner(System.in);
		int searchInt = sc.nextInt();
		
		// search for selected value in array
		int position = 0;
		for (int i = 0; i < array1.length; i++) {
			if (array1[i] == searchInt) {
				position = i + 1;
				System.out.println("Found search value: " + searchInt + " at array index: " +
			       i + " at physical location: " + position);
			}
		}
		
		// after loop, close scanner
	    sc.close();
	}
}
