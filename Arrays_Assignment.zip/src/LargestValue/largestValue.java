// Class Name: largestValue.java
// Package: LargestValue
// Author: Patrick Hagan
// Description: Find largest value in array
// Date: July 18, 2018
// *******************************************************************************************************
package LargestValue;

public class largestValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array1 = {10, 3, 5, 8, 2, 4, 9, 6, 8, 8};
		int largest = 0;
		int position = 0;
		int index = 0;
		
		// display values in array1
		System.out.println("array to search: ");	
	    for (int i = 0; i < array1.length; i++) {
	       System.out.print(array1[i] + " ");
	    }
		
		// search for largest value in array
		for (int i = 0; i < array1.length - 1; i++) {
			if (array1[i] > array1[i + 1]) {
				index = i;
				position = i + 1;
				largest = array1[i];
			}
		}
		
		System.out.println("\n" + "Largest value: " + largest + " at array index: " +
			       index + " at physical location: " + position);
	}
}