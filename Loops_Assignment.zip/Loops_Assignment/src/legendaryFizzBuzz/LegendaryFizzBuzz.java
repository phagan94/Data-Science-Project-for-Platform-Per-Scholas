//Class Name: LegendaryFizzBuzz.java
//Package: legendaryFizzBuzz
//Author: Patrick Hagan
//Description: Print Fizz for all numbers divisible by 3 and Buzz for divisible by 5
//Date: July 30, 2018
//***************************************************************************************************************************
// Create one project for this assignment; call it "Loops_Assignment". For each of these questions, create separate packages 
// under this project. Name each package to an appropriate format, such as "1", "2", "3", etc. When completed, zip your whole
// project folder and submit the zipped folder on here.
//  
// 1) The Legendary FizzBuzz
// Write a program that prints the numbers from 1 to 100.
// But for multiples of three print "Fizz" instead of the number.
// For the multiples of five print "Buzz".
// For numbers which are multiples of both three and five print "FizzBuzz".
//
//***************************************************************************************************************************
package legendaryFizzBuzz;

public class LegendaryFizzBuzz {

	public static void main(String[] args) {
		for (int i = 1; i < 101; i++) {
			if ((i % 3 == 0) && (i % 5 == 0)) 
			{
				System.out.println("FizzBuzz");
			} 
			else if (i % 3 == 0) 
			{
				System.out.println("Fizz");
			} 
			else if (i % 5 == 0) 
			{
				System.out.println("Buzz");
			}
			else 
			{
				System.out.println(i);
			}
		}
	}

}
