//Class Name: NestedLoops.java
//Package: nestedLoops
//Author: Patrick Hagan
//Description: Generate different combinations of 8s
//Date: July 30, 2018
//***************************************************************************************************************************
// Create one project for this assignment; call it "Loops_Assignment". For each of these questions, create separate packages 
// under this project. Name each package to an appropriate format, such as "1", "2", "3", etc. When completed, zip your whole
// project folder and submit the zipped folder on here.
//  
// 7) Create a program using nested loops that would generate the following output:
// 1.
// 88888888
// 88888888
// 88888888
// 88888888
// 88888888
// 2.
// 8888
// 888
// 88
// 8
// 3. 
// 8
// 8
// 8
// 8
// 8
//***************************************************************************************************************************
package nestedLoops;

public class NestedLoops {

	public static void main(String[] args) {
		System.out.println("1.");
		for (int row = 0; row < 5; row++) {
			for (int col = 0; col < 9; col++) {
				System.out.print("8");
			}
			System.out.println("");
		}
		 
		System.out.println("\n2.");
		int rowEnd = 4;
		int colStart = 4;
		for (int row = 0; row < rowEnd; row++) {
			for (int col = 0; col < colStart; col++) {
				System.out.print("8");
		 	}
			System.out.println("");
			--colStart;
		}
		
		System.out.println("\n3.");
		for (int i = 0; i < 5; i++) {
			System.out.println("8");
		}
	}
}
