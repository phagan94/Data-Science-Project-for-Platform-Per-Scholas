//Class Name: EvenThree.java
//Package: evenThree
//Author: Patrick Hagan
//Description: Even numbers from 10 to inclusive; skipping 16 three ways
//Date: July 30, 2018
//***************************************************************************************************************
// 5) Create a JAVA program to write the even numbers from 10 to 20, both included, except 16, in 3 different ways: 
// - Incrementing 2 in each step (use "continue" to skip 16)
// - Incrementing 1 in each step (use "continue")
// - With endless loop (using "break" & "continue") 
//***************************************************************************************************************
package evenThree;

public class EvenThree {

	public static void main(String[] args) {
		// if you use step 2, you get only odd numbers because it starts at 1 so nothing prints
		System.out.println("Incrementing 2 in each step (use continue to skip 16): ");
		System.out.println("Even numbers from 10 to 20, both included, except 16");
		for (int i = 1; i <= 20; i = i + 2) {
			if (i % 2 == 0)  
			{
				if(i == 16) {
					continue;
				}
				else
				{
					System.out.println("Even: " + i);
				}
			}
		}	

		System.out.println("Incrementing 1 in each step (use continue to skip 16): ");
		System.out.println("Even numbers from 10 to 20, both included, except 16");
		for (int i = 1; i < 21; i++) {
			if (i % 2 == 0)  
			{
				if(i == 16) {
					continue;
				}
				else
				{
					System.out.println(i);
				}
			} 
		}
		
		System.out.println("With endless loop using break to get out at 16): ");
		System.out.println("Even numbers from 10 to 20, both included, except 16");
		for (int i = 1; i > 0; i++) {
			if (i % 2 == 0)  
			{
				if(i == 16) {
					continue;
				}
				else
				{
					System.out.println(i);
				}
				if(i >= 20) {
					break;
				}
			} 
		}
	}
}
