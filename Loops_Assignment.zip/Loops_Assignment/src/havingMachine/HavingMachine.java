//Class Name: HavingMachine.java
//Package: havingMachine
//Author: Patrick Hagan
//Description: Half the input until 1
//Date: July 30, 2018
//***************************************************************************************************************************
// Create one project for this assignment; call it "Loops_Assignment". For each of these questions, create separate packages 
// under this project. Name each package to an appropriate format, such as "1", "2", "3", etc. When completed, zip your whole
// project folder and submit the zipped folder on here.
//  
// 2) The Halving Machine
// Create a loop that will take an integer from user input.
// If the integer is odd, add 1 and then divide that by 2 and print the new number.
// If the integer is even, just divide by 2 and print the new number.
// Continue doing this until you reach 1.
// If the user enters 0 or negative number, print out "HEY! That's against the rules." and end the program.
//
//***************************************************************************************************************************
package havingMachine;

import java.util.Scanner;

public class HavingMachine {
		
	public static void main(String[] args) {
		boolean EOF = false;
		Scanner sc = new Scanner(System.in);
		
		do 
		{
			System.out.println("Please enter an interger number you would like to have the halfs of: ");
		
			int inputInt = sc.nextInt();
			if (inputInt <= 0) {
				System.out.println("HEY! That's against the rules.");
				EOF = true;
			} 
			else
			{
				System.out.println("The half of your number: " + inputInt + " are as follows: ");
				int answer = inputInt;
				while (answer > 0) {
					answer = answer / 2;
					System.out.println(answer);
					
					if (answer <= 1) {
						break;
					}
				}	
			}
			
		} while (EOF != true);
		
		// after loop, close scanner
	    sc.close();
	} 
}
