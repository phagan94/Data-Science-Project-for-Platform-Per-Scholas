//Class Name: LetterAtATime.java
//Package: letterAtATime
//Author: Patrick Hagan
//Description: Print single characters in a String
//Date: July 30, 2018
//***************************************************************************************************************************
// Create one project for this assignment; call it "Loops_Assignment". For each of these questions, create separate packages 
// under this project. Name each package to an appropriate format, such as "1", "2", "3", etc. When completed, zip your whole
// project folder and submit the zipped folder on here.
//  
// 3) Letter at a time
// Did you know that using a loop, you can examine a String one letter at a time?
// The two key built-in String methods are length() and charAt().
// length() returns an int representing the total number of characters in the String
// charAt( int n ) returns character at position n of the string (the character positions start at 0)
// Try using to print the character and position number for every character in a string from user input!
// Your output could look like the following:
// What is your message?
// >Hello World
// Here are all the characters, one at a time:
// 0: 'H'
// 1: 'e'
// 2: 'l'
// 3: 'l'
// 4: 'o'
// 5: ' '
// 6: 'W'
// 7: 'o'
// 8: 'r'
// 9: 'l'
// 10: 'd'
// 
//***************************************************************************************************************************
package letterAtATime;

import java.util.Scanner;

public class LetterAtATime {
	public static void main(String[] args) {
		System.out.println("\n" + "Please enter the string you would like to get the characters for: ");
		Scanner sc = new Scanner(System.in);
		String stringIn = sc.nextLine();

		for (int i = 0; i < stringIn.length(); i++) {
			System.out.println(i + ": \'" + stringIn.charAt(i) + "\'");
		}
		
		// after loop, close scanner
	    sc.close();
	} 
}
