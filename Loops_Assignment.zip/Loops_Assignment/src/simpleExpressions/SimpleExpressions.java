//Class Name: SimpleExpressions.java
//Package: simpleExpressions
//Author: Patrick Hagan
//Description: Create a simple calculator (+ - * /)
//Date: July 30, 2018
//***************************************************************************************************************************
// Create one project for this assignment; call it "Loops_Assignment". For each of these questions, create separate packages 
// under this project. Name each package to an appropriate format, such as "1", "2", "3", etc. When completed, zip your whole
// project folder and submit the zipped folder on here.
//  
// 6) Write a program that will evaluate simple expressions such as 17 + 3 and 3.14159 * 4.7. The expressions are to be typed 
// in by the user. The input always consist of a number, followed by an operator, followed by another number. The operators 
// that are allowed are +, -, *, and /. Your program should read an expression, print its value, read another expression, 
// print its value, and so on. The program should end when the user enters 0 as the first number on the line.
// 
//***************************************************************************************************************************
package simpleExpressions;

import java.util.Scanner;

public class SimpleExpressions {
	public static void main(String[] args) {
		double firstNumber = 0;
		double secondNumber = 0;
		String expression = " ";
		Scanner sc = new Scanner(System.in);
		
		do {
			System.out.println("Please enter your first number or zero (0) to end: ");
			firstNumber = sc.nextDouble();
			if (firstNumber == 0.0) {
				System.out.println("The program SimpleExpressions has ended.");
				break;
			}
			
			System.out.println("\n" + "Please enter your second number: ");
			secondNumber = sc.nextDouble();

			System.out.println("\n" + "Please enter the expression you would like to calculate (+, -, *, /): ");
			expression = sc.next();
		
			switch (expression) {
				case "+" : {
					System.out.println("The value of this expression: " + firstNumber + " + " + secondNumber + " is: " + 
							(firstNumber + secondNumber));  
					break;
				}
				case "-" : {
					System.out.println("The value of this expression: " + firstNumber + " - " + secondNumber + " is: " + 
							(firstNumber - secondNumber));   
					break;
				}
				case "*" : {
					System.out.println("The value of this expression: " + firstNumber + " * " + secondNumber + " is: " + 
							(firstNumber * secondNumber)); 
					break;
				}
				case "/" : {
					System.out.println("The value of this expression: " + firstNumber + " /"
							+ " " + secondNumber + " is: " + 
							(firstNumber / secondNumber)); 
					break;
				}
				default :
				{
					System.out.println("You did not enter the correct expression (+, -, *, /), please try again.");
					break;
				}
			 } 
		} while (firstNumber != 0.0);

		// after done with scanner, close scanner
	    sc.close();
	} 
}
