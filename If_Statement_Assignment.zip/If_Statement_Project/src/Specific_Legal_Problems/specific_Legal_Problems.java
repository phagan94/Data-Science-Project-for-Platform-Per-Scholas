package Specific_Legal_Problems;
//Class Name: Specific_Legal_Problems.java
//Package: specific_Legal_Problems
//Author: Patrick Hagan
//Description: Enter age to determine if you can drive, vote, rent a car, or completely legal
//           Tested with a for loop
//Date: July 16, 2018
//P.S. I realize the names are not exactly Java correct; I forget the exact rules
//*******************************************************************************************************
public class specific_Legal_Problems {

	public static void main(String[] args) {
		int age = 0;
		
		// for loop to test if statement
		for(int i = 0; i < 27; i++) {
			age = i;
			if (age < 16) {
				System.out.println("Age: "+ i + " You can\'t drive."); 
			} else if (age < 18) {
				System.out.println("Age: "+ i + " You can\'t vote.");
			} else if (age < 25) {
				System.out.println("Age: "+ i + " You can\'t rent a car.");
			} else {
				System.out.println("Age: "+ i + " You can do anything that\'s legal.");
		}
		}
	}

}
