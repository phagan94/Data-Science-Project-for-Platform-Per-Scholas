//Class Name: Space_Weight.java
//Package: Space_Weight
//Author: Patrick Hagan
//Description: Enter weight and choose planet to get relative weight on that planet
//Date: July 16, 2018
//P.S. I realize the names are not exactly Java correct; I forget the exact rules
//*******************************************************************************************************
package Space_Weight;

import  java.util.Scanner;

public class Space_Weight {
	public double spaceWeight (int tempPlanet, int tempWeight) {
		double gravity[] = {0.0, 0.78, 0.39, 2.65, 1.17, 1.05, 1.23};
		double relativeWeight = 0.0;
		
		if (tempPlanet > 0 && tempPlanet < 7) {
			relativeWeight = (gravity[tempPlanet] * tempWeight);
		}
		return relativeWeight;
	}
	
	public static void main(String[] args) {
		int myWeightIn = 0;
		int myPlanetIn = 0;
		double myWeightOut = 0.0;
		String planets[] = {"Not planet", "Venus", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"};
		
		// Note: need to use print to get entry at end of line after ':'
		// println puts input on next line
		System.out.println("Please enter your current earth weight: ");
						
		Scanner sc = new Scanner(System.in); 
		myWeightIn = sc.nextInt(); 
		
		System.out.println("I have information for the following planets: ");
		System.out.println("1. Venus ");
		System.out.println("2. Mars ");
		System.out.println("3. Jupiter ");
		System.out.println("4. Saturn ");
		System.out.println("5. Uranus ");
		System.out.println("6. Neptune ");
		
		System.out.println("Please enter your choice of planet: ");
		myPlanetIn = sc.nextInt();
		
		SpaceWeight spwt = new SpaceWeight();
		myWeightOut = spwt.spaceWeight (myPlanetIn, myWeightIn);
					
		System.out.println("Your relative weight on: " + planets[myPlanetIn] + " is " + myWeightOut);
	    //	System.out.println(" " + "\n");
		
		sc.close();
		}
}
