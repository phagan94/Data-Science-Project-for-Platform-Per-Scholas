//Class Name: Day_of_the_Week.java
//Package: N002_Day_of_the_Week
//Author: Patrick Hagan
//Description: Enter number to determine text for day of the week
//           Tested with a for loop 
//Date: July 16, 2018
//P.S. I realize the names are not exactly Java correct; I forget the exact rules
//*******************************************************************************************************
package Day_of_the_Week;

import  java.util.Scanner;

public class Day_of_the_Week {
	public String dayofWeek (int tempDay) {
		String tempString;
		if        (tempDay == 1) {
			tempString = "Monday"; 
		} else if (tempDay == 2) {
			tempString = "Tuesday"; 
		} else if (tempDay == 3) {
			tempString = "Wednesday"; 
		} else if (tempDay == 4) {
			tempString = "Thursday"; 
		} else if (tempDay == 5 ) {
			tempString = "Friday"; 
		} else if (tempDay == 6) {
			tempString = "Saturday"; 
		} else if (tempDay == 7) {
			tempString = "Sunday"; 
		} else {
			tempString = "Error";
		}
		return tempString;
	}
	
	public static void main(String[] args) {
		int myDay = 0;
		String myString = " ";
		
		Day_of_the_Week dow = new Day_of_the_Week();
		System.out.println("Please enter an Integer (1-7):");
		
		Scanner sc = new Scanner(System.in); 
		
		// for added for multiple tests at one time rather than keep running separately
		for (int i = 0; i < 9; i++) {
			myDay = Integer.parseInt(sc.nextLine());
		
			myString = dow.dayofWeek (myDay);
					
			System.out.println("Weekday " + myDay + " is " + myString);
	    //	System.out.println(" " + "\n");
		
		}
	sc.close();
	}
}
