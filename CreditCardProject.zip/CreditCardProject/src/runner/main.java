package runner;

import java.io.IOException;
import java.sql.SQLException;

import dao.dbconnection_abstract;

public class main  {

	public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		Tranaction_runnable t = new Tranaction_runnable();
		t.getTotalByType();
		
		
		
		
	}
	
	

}
