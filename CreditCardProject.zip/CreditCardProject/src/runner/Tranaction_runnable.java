package runner;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import dao.TransactionDao;
import dao.dbconnection_abstract;
import model.transaction;
import resources.myQuries;

public class Tranaction_runnable extends dbconnection_abstract{
	public void getTotalByType() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{
			
		myconnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter transaction Type:");
		
		String type = sc.nextLine();
		
		TransactionDao td = new TransactionDao();
		transaction mytransaction = td.gettotalbyType(type);
		System.out.println(mytransaction.getCount());
	}
		
		
		
	}


	

