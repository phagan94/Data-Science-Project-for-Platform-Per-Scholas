package resources;

public class myQuries {
	public final static String totaByType = "select sum(transaction_value), count(*)" 
		+ "from CDW_SAPP.CDW_SAPP_CREDITCARD " 
		+ "where TRANSACTION_TYPE = ? " 
		+ "group by TRANSACTION_TYPE";
	public final static String selectAllBranches    = "select * from CDW_SAPP.CDW_SAPP_BRANCH";
	public final static String selectAllCreditCards = "select * from CDW_SAPP.CDW_SAPP_CREDITCARD";
	public final static String selectAllCustomers   = "select * from CDW_SAPP.CDW_SAPP_CUSTOMER";
	public final static String selectAllD_Times     = "select * from CDW_SAPP.CDW_SAPP_D_TIME";
	
	public final static String selectBranch     = "select * from CDW_SAPP.CDW_SAPP_BRANCH"
			+ " where BRANCH_CODE = ? ";
	public final static String selectCreditCard = "select * from CDW_SAPP.CDW_SAPP_CREDITCARD"
			+ " where TRANSACTION_ID = ? "; 
	public final static String selectCustomer   = "select * from CDW_SAPP.CDW_SAPP_CUSTOMER"
			+ "where CUST_SSN = ? "  
			+ "and CREDIT_CARD_NO = ? ";
	public final static String selectD_Time     = "select * from CDW_SAPP.CDW_SAPP_D_TIME"
			+ " where TIME_TIME_ID = ? ";
}
