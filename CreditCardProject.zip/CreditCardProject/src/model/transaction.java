package model;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import dao.dbconnection_abstract;

public class transaction extends dbconnection_abstract{
	protected int day, month, year, ssn, branchCode, count, Value;
	public int getValue() {
		return Value;
	}

	public void setValue(int value) {
		Value = value;
	}

	protected String cardNo, type;

	
	
public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getSsn() {
		return ssn;
	}

	public void setSsn(int ssn) {
		this.ssn = ssn;
	}

	public int getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(int branchCode) {
		this.branchCode = branchCode;
	}

	public int getCount() {
		return count;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

public void setDay(int day) {
	this.day = day;
}

public int getDay()
{
	return day;
}

public void setCount(int count) {
	// TODO Auto-generated method stub
	this.count  =      count;
}

}
