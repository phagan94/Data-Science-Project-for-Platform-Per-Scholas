/**
 * 
 */
package model;

/**
 * @author Patrick Hagan
 * Date: September 5, 2018
 * Description: CreditCard class with default constructors, hash code, equals, toString and getters and setters
 */


public class CreditCard {
	
	  private int     transaction_id;  
	  private int     tday;                          
	  private int     tmonth;                     
	  private int     tyear;                      
	  private int     credit_card_no;      
	  private int     cust_ssn;                  
	  private int     branch_code;           
	  private String  transaction_type;
	  private double  transaction_value;

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CreditCard [transaction_id=" + transaction_id + ", tday=" + tday + ", tmonth=" + tmonth + ", tyear="
				+ tyear + ", credit_card_no=" + credit_card_no + ", cust_ssn=" + cust_ssn + ", branch_code="
				+ branch_code + ", transaction_type=" + transaction_type + ", transaction_value=" + transaction_value
				+ "]";
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + branch_code;
		result = prime * result + credit_card_no;
		result = prime * result + cust_ssn;
		result = prime * result + tday;
		result = prime * result + tmonth;
		result = prime * result + transaction_id;
		result = prime * result + ((transaction_type == null) ? 0 : transaction_type.hashCode());
		long temp;
		temp = Double.doubleToLongBits(transaction_value);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + tyear;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CreditCard other = (CreditCard) obj;
		if (branch_code != other.branch_code)
			return false;
		if (credit_card_no != other.credit_card_no)  
			return false;
		if (cust_ssn != other.cust_ssn)
			return false;
		if (tday != other.tday)
			return false;
		if (tmonth != other.tmonth)
			return false;
		if (transaction_id != other.transaction_id)
			return false;
		if (transaction_type == null) {
			if (other.transaction_type != null)
				return false;
		} else if (!transaction_type.equals(other.transaction_type))
			return false;
		if (Double.doubleToLongBits(transaction_value) != Double.doubleToLongBits(other.transaction_value))
			return false;
		if (tyear != other.tyear)
			return false;
		return true;
	}

	/**
	 * @return the transaction_id
	 */
	public int getTransaction_id() {
		return transaction_id;
	}

	/**
	 * @param transaction_id the transaction_id to set
	 */
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}

	/**
	 * @return the tday
	 */
	public int getTday() {
		return tday;
	}

	/**
	 * @param tday the tday to set
	 */
	public void setTday(int tday) {
		this.tday = tday;
	}

	/**
	 * @return the tmonth
	 */
	public int getTmonth() {
		return tmonth;
	}

	/**
	 * @param tmonth the tmonth to set
	 */
	public void setTmonth(int tmonth) {
		this.tmonth = tmonth;
	}

	/**
	 * @return the tyear
	 */
	public int getTyear() {
		return tyear;
	}

	/**
	 * @param tyear the tyear to set
	 */
	public void setTyear(int tyear) {
		this.tyear = tyear;
	}

	/**
	 * @return the credit_card_no
	 */
	public int getCredit_card_no() {
		return credit_card_no;
	}

	/**
	 * @param credit_card_no the credit_card_no to set
	 */
	public void setCredit_card_no(int credit_card_no) {
		this.credit_card_no = credit_card_no;
	}

	/**
	 * @return the cust_ssn
	 */
	public int getCust_ssn() {
		return cust_ssn;
	}

	/**
	 * @param cust_ssn the cust_ssn to set
	 */
	public void setCust_ssn(int cust_ssn) {
		this.cust_ssn = cust_ssn;
	}

	/**
	 * @return the branch_code
	 */
	public int getBranch_code() {
		return branch_code;
	}

	/**
	 * @param branch_code the branch_code to set
	 */
	public void setBranch_code(int branch_code) {
		this.branch_code = branch_code;
	}

	/**
	 * @return the transaction_type
	 */
	public String getTransaction_type() {
		return transaction_type;
	}

	/**
	 * @param transaction_type the transaction_type to set
	 */
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	/**
	 * @return the transaction_value
	 */
	public double getTransaction_value() {
		return transaction_value;
	}

	/**
	 * @param transaction_value the transaction_value to set
	 */
	public void setTransaction_value(double transaction_value) {
		this.transaction_value = transaction_value;
	}

	/**
	 *  do nothing constructor 
	 */
	public CreditCard() {
		// Does nothing
	}

	/**
	 * @param transaction_id
	 * @param tday
	 * @param tmonth
	 * @param tyear
	 * @param credit_card_no
	 * @param cust_ssn
	 * @param branch_code
	 * @param transaction_type
	 * @param transaction_value
	 */
	public CreditCard(int transaction_id, int tday, int tmonth, int tyear, int credit_card_no, int cust_ssn,
			int branch_code, String transaction_type, double transaction_value) {
		super();
		this.transaction_id = transaction_id;
		this.tday = tday;
		this.tmonth = tmonth;
		this.tyear = tyear;
		this.credit_card_no = credit_card_no;
		this.cust_ssn = cust_ssn;
		this.branch_code = branch_code;
		this.transaction_type = transaction_type;
		this.transaction_value = transaction_value;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
