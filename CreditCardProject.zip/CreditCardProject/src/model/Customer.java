/**
 * 
 */
package model;

/**
 * @author Patrick Hagan
 * Date: September 5, 2018
 * Description: Customer class with default constructors, hash code, equals, toString and getters and setters
 *
 */

import java.sql.Timestamp;

public class Customer {
	
	private String    first_name;          
	private String    middle_name;      
	private String    last_name;            
	private int       ssn;                        
	private int       credit_card_no;   
	private String    apt_no;                 
	private String    street_name;        
	private String    cust_city;              
	private String    cust_state;            
	private String    cust_country;       
	private String    cust_zip;                
    private int 	  cust_phone;
	private String 	  cust_email;           
	private Timestamp last_updated;

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Customer [first_name=" + first_name + ", middle_name=" + middle_name + ", last_name=" + last_name
				+ ", ssn=" + ssn + ", credit_card_no=" + credit_card_no + ", apt_no=" + apt_no + ", street_name="
				+ street_name + ", cust_city=" + cust_city + ", cust_state=" + cust_state + ", cust_country="
				+ cust_country + ", cust_zip=" + cust_zip + ", cust_phone=" + cust_phone + ", cust_email=" + cust_email
				+ ", last_updated=" + last_updated + "]";
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((apt_no == null) ? 0 : apt_no.hashCode());
		result = prime * result + credit_card_no;
		result = prime * result + ((cust_city == null) ? 0 : cust_city.hashCode());
		result = prime * result + ((cust_country == null) ? 0 : cust_country.hashCode());
		result = prime * result + ((cust_email == null) ? 0 : cust_email.hashCode());
		result = prime * result + cust_phone;
		result = prime * result + ((cust_state == null) ? 0 : cust_state.hashCode());
		result = prime * result + ((cust_zip == null) ? 0 : cust_zip.hashCode());
		result = prime * result + ((first_name == null) ? 0 : first_name.hashCode());
		result = prime * result + ((last_name == null) ? 0 : last_name.hashCode());
		result = prime * result + ((last_updated == null) ? 0 : last_updated.hashCode());
		result = prime * result + ((middle_name == null) ? 0 : middle_name.hashCode());
		result = prime * result + ssn;
		result = prime * result + ((street_name == null) ? 0 : street_name.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (apt_no == null) {
			if (other.apt_no != null)
				return false;
		} else if (!apt_no.equals(other.apt_no))
			return false;
		if (credit_card_no != other.credit_card_no)
			return false;
		if (cust_city == null) {
			if (other.cust_city != null)
				return false;
		} else if (!cust_city.equals(other.cust_city))
			return false;
		if (cust_country == null) {
			if (other.cust_country != null)
				return false;
		} else if (!cust_country.equals(other.cust_country))
			return false;
		if (cust_email == null) {
			if (other.cust_email != null)
				return false;
		} else if (!cust_email.equals(other.cust_email))
			return false;
		if (cust_phone != other.cust_phone)
			return false;
		if (cust_state == null) {
			if (other.cust_state != null)
				return false;
		} else if (!cust_state.equals(other.cust_state))
			return false;
		if (cust_zip == null) {
			if (other.cust_zip != null)
				return false;
		} else if (!cust_zip.equals(other.cust_zip))
			return false;
		if (first_name == null) {
			if (other.first_name != null)
				return false;
		} else if (!first_name.equals(other.first_name))
			return false;
		if (last_name == null) {
			if (other.last_name != null)
				return false;
		} else if (!last_name.equals(other.last_name))
			return false;
		if (last_updated == null) {
			if (other.last_updated != null)
				return false;
		} else if (!last_updated.equals(other.last_updated))
			return false;
		if (middle_name == null) {
			if (other.middle_name != null)
				return false;
		} else if (!middle_name.equals(other.middle_name))
			return false;
		if (ssn != other.ssn)
			return false;
		if (street_name == null) {
			if (other.street_name != null)
				return false;
		} else if (!street_name.equals(other.street_name))
			return false;
		return true;
	}

	/**
	 * @return the first_name
	 */
	public String getFirst_name() {
		return first_name;
	}

	/**
	 * @param first_name the first_name to set
	 */
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	/**
	 * @return the middle_name
	 */
	public String getMiddle_name() {
		return middle_name;
	}

	/**
	 * @param middle_name the middle_name to set
	 */
	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}

	/**
	 * @return the last_name
	 */
	public String getLast_name() {
		return last_name;
	}

	/**
	 * @param last_name the last_name to set
	 */
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	/**
	 * @return the ssn
	 */
	public int getSsn() {
		return ssn;
	}

	/**
	 * @param ssn the ssn to set
	 */
	public void setSsn(int ssn) {
		this.ssn = ssn;
	}

	/**
	 * @return the credit_card_no
	 */
	public int getCredit_card_no() {
		return credit_card_no;
	}

	/**
	 * @param credit_card_no the credit_card_no to set
	 */
	public void setCredit_card_no(int credit_card_no) {
		this.credit_card_no = credit_card_no;
	}

	/**
	 * @return the apt_no
	 */
	public String getApt_no() {
		return apt_no;
	}

	/**
	 * @param apt_no the apt_no to set
	 */
	public void setApt_no(String apt_no) {
		this.apt_no = apt_no;
	}

	/**
	 * @return the street_name
	 */
	public String getStreet_name() {
		return street_name;
	}

	/**
	 * @param street_name the street_name to set
	 */
	public void setStreet_name(String street_name) {
		this.street_name = street_name;
	}

	/**
	 * @return the cust_city
	 */
	public String getCust_city() {
		return cust_city;
	}

	/**
	 * @param cust_city the cust_city to set
	 */
	public void setCust_city(String cust_city) {
		this.cust_city = cust_city;
	}

	/**
	 * @return the cust_state
	 */
	public String getCust_state() {
		return cust_state;
	}

	/**
	 * @param cust_state the cust_state to set
	 */
	public void setCust_state(String cust_state) {
		this.cust_state = cust_state;
	}

	/**
	 * @return the cust_country
	 */
	public String getCust_country() {
		return cust_country;
	}

	/**
	 * @param cust_country the cust_country to set
	 */
	public void setCust_country(String cust_country) {
		this.cust_country = cust_country;
	}

	/**
	 * @return the cust_zip
	 */
	public String getCust_zip() {
		return cust_zip;
	}

	/**
	 * @param cust_zip the cust_zip to set
	 */
	public void setCust_zip(String cust_zip) {
		this.cust_zip = cust_zip;
	}

	/**
	 * @return the cust_phone
	 */
	public int getCust_phone() {
		return cust_phone;
	}

	/**
	 * @param cust_phone the cust_phone to set
	 */
	public void setCust_phone(int cust_phone) {
		this.cust_phone = cust_phone;
	}

	/**
	 * @return the cust_email
	 */
	public String getCust_email() {
		return cust_email;
	}

	/**
	 * @param cust_email the cust_email to set
	 */
	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}

	/**
	 * @return the last_updated
	 */
	public Timestamp getLast_updated() {
		return last_updated;
	}

	/**
	 * @param last_updated the last_updated to set
	 */
	public void setLast_updated(Timestamp last_updated) {
		this.last_updated = last_updated;
	}

	/**
	 * Do nothing constructor
	 */
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param first_name
	 * @param middle_name
	 * @param last_name
	 * @param ssn
	 * @param credit_card_no
	 * @param apt_no
	 * @param street_name
	 * @param cust_city
	 * @param cust_state
	 * @param cust_country
	 * @param cust_zip
	 * @param cust_phone
	 * @param cust_email
	 * @param last_updated
	 */
	public Customer(String first_name, String middle_name, String last_name, int ssn, int credit_card_no,
			String apt_no, String street_name, String cust_city, String cust_state, String cust_country,
			String cust_zip, int cust_phone, String cust_email, Timestamp last_updated) {
		super();
		this.first_name = first_name;
		this.middle_name = middle_name;
		this.last_name = last_name;
		this.ssn = ssn;
		this.credit_card_no = credit_card_no;
		this.apt_no = apt_no;
		this.street_name = street_name;
		this.cust_city = cust_city;
		this.cust_state = cust_state;
		this.cust_country = cust_country;
		this.cust_zip = cust_zip;
		this.cust_phone = cust_phone;
		this.cust_email = cust_email;
		this.last_updated = last_updated;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
