package model;

/**
 * @author Patrick Hagan
 * Date: September 5, 2018
 * Description: D_Time class with default constructors, hash code, equals, toString and getters and setters
 */

public class D_Time {

	private int     time_day;                          
	private int     time_month;  
	private String  time_quarter;
	private int     time_year;                      
	private String  time_time_id;  
	
	/**
	 * @return the time_time_id
	 */
	public String getTime_time_id() {
		return time_time_id;
	}

	/**
	 * @param time_time_id the time_time_id to set
	 */
	public void setTime_time_id(String time_time_id) {
		this.time_time_id = time_time_id;
	}

	/**
	 * @return the time_day
	 */
	public int getTime_day() {
		return time_day;
	}

	/**
	 * @param time_day the time_day to set
	 */
	public void setTime_day(int time_day) {
		this.time_day = time_day;
	}

	/**
	 * @return the time_month
	 */
	public int getTime_month() {
		return time_month;
	}

	/**
	 * @param time_month the time_month to set
	 */
	public void setTime_month(int time_month) {
		this.time_month = time_month;
	}

	/**
	 * @return the time_quarter
	 */
	public String getTime_quarter() {
		return time_quarter;
	}

	/**
	 * @param time_quarter the time_quarter to set
	 */
	public void setTime_quarter(String time_quarter) {
		this.time_quarter = time_quarter;
	}

	/**
	 * @return the time_year
	 */
	public int getTime_year() {
		return time_year;
	}

	/**
	 * @param time_year the time_year to set
	 */
	public void setTime_year(int time_year) {
		this.time_year = time_year;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "D_Time [time_time_id=" + time_time_id + ", time_day=" + time_day + ", time_month=" + time_month
				+ ", time_quarter=" + time_quarter + ", time_year=" + time_year + "]";
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + time_day;
		result = prime * result + time_month;
		result = prime * result + ((time_quarter == null) ? 0 : time_quarter.hashCode());
		result = prime * result + ((time_time_id == null) ? 0 : time_time_id.hashCode());
		result = prime * result + time_year;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		D_Time other = (D_Time) obj;
		if (time_day != other.time_day)
			return false;
		if (time_month != other.time_month)
			return false;
		if (time_quarter == null) {
			if (other.time_quarter != null)
				return false;
		} else if (!time_quarter.equals(other.time_quarter))
			return false;
		if (time_time_id == null) {
			if (other.time_time_id != null)
				return false;
		} else if (!time_time_id.equals(other.time_time_id))
			return false;
		if (time_year != other.time_year)
			return false;
		return true;
	}
	
	public D_Time() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
