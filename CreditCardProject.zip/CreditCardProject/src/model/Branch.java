/**
 * 
 */
package model;

/**
 * @author Patrick Hagan
 * Date: September 5, 2018
 * Description: Branch (Bank) class with default constructors, hash code, equals, toString and getters and setters
 */


import java.sql.Timestamp;

public class Branch {
	
		private int 	  branch_code; 
    	private String 	  branch_name;
	    private String 	  branch_street;    
	    private String 	  branch_city;         
	    private String 	  branch_state;       
	    private int 	  branch_zip;
	    private String 	  branch_phone;    
	    private Timestamp last_updated;
		
		/**
		 * @return the branch_code
		 */
		public int getBranch_code() {
			return branch_code;
		}

		/**
		 * @param branch_code the branch_code to set
		 */
		public void setBranch_code(int branch_code) {
			this.branch_code = branch_code;
		}

		/**
		 * @return the branch_name
		 */
		public String getBranch_name() {
			return branch_name;
		}

		/**
		 * @param branch_name the branch_name to set
		 */
		public void setBranch_name(String branch_name) {
			this.branch_name = branch_name;
		}

		/**
		 * @return the branch_street
		 */
		public String getBranch_street() {
			return branch_street;
		}

		/**
		 * @param branch_street the branch_street to set
		 */
		public void setBranch_street(String branch_street) {
			this.branch_street = branch_street;
		}

		/**
		 * @return the branch_city
		 */
		public String getBranch_city() {
			return branch_city;
		}

		/**
		 * @param branch_city the branch_city to set
		 */
		public void setBranch_city(String branch_city) {
			this.branch_city = branch_city;
		}

		/**
		 * @return the branch_state
		 */
		public String getBranch_state() {
			return branch_state;
		}

		/**
		 * @param branch_state the branch_state to set
		 */
		public void setBranch_state(String branch_state) {
			this.branch_state = branch_state;
		}

		/**
		 * @return the branch_zip
		 */
		public int getBranch_zip() {
			return branch_zip;
		}

		/**
		 * @param branch_zip the branch_zip to set
		 */
		public void setBranch_zip(int branch_zip) {
			this.branch_zip = branch_zip;
		}

		/**
		 * @return the branch_phone
		 */
		public String getBranch_phone() {
			return branch_phone;
		}

		/**
		 * @param branch_phone the branch_phone to set
		 */
		public void setBranch_phone(String branch_phone) {
			this.branch_phone = branch_phone;
		}

		/**
		 * @return the last_updated
		 */
		public Timestamp getLast_updated() {
			return last_updated;
		}

		/**
		 * @param last_updated the last_updated to set
		 */
		public void setLast_updated(Timestamp last_updated) {
			this.last_updated = last_updated;
		}

	
		/* (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "Branch [branch_code=" + branch_code + ", branch_name=" + branch_name + ", branch_street="
					+ branch_street + ", branch_city=" + branch_city + ", branch_state=" + branch_state
					+ ", branch_zip=" + branch_zip + ", branch_phone=" + branch_phone + ", last_updated=" + last_updated
					+ "]";
		}

		/* (non-Javadoc)
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((branch_city == null) ? 0 : branch_city.hashCode());
			result = prime * result + branch_code;
			result = prime * result + ((branch_name == null) ? 0 : branch_name.hashCode());
			result = prime * result + ((branch_phone == null) ? 0 : branch_phone.hashCode());
			result = prime * result + ((branch_state == null) ? 0 : branch_state.hashCode());
			result = prime * result + ((branch_street == null) ? 0 : branch_street.hashCode());
			result = prime * result + branch_zip;
			result = prime * result + ((last_updated == null) ? 0 : last_updated.hashCode());
			return result;
		}

		/* (non-Javadoc)
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Branch other = (Branch) obj;
			if (branch_city == null) {
				if (other.branch_city != null)
					return false;
			} else if (!branch_city.equals(other.branch_city))
				return false;
			if (branch_code != other.branch_code)
				return false;
			if (branch_name == null) {
				if (other.branch_name != null)
					return false;
			} else if (!branch_name.equals(other.branch_name))
				return false;
			if (branch_phone == null) {
				if (other.branch_phone != null)
					return false;
			} else if (!branch_phone.equals(other.branch_phone))
				return false;
			if (branch_state == null) {
				if (other.branch_state != null)
					return false;
			} else if (!branch_state.equals(other.branch_state))
				return false;
			if (branch_street == null) {
				if (other.branch_street != null)
					return false;
			} else if (!branch_street.equals(other.branch_street))
				return false;
			if (branch_zip != other.branch_zip)
				return false;
			if (last_updated == null) {
				if (other.last_updated != null)
					return false;
			} else if (!last_updated.equals(other.last_updated))
				return false;
			return true;
		}

	/**
	 *  Do nothing constructor
	 */
	public Branch() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param branch_code
	 * @param branch_name
	 * @param branch_street
	 * @param branch_city
	 * @param branch_state
	 * @param branch_zip
	 * @param branch_phone
	 * @param last_updated
	 */
	public Branch(int branch_code, String branch_name, String branch_street, String branch_city,
			String branch_state, int branch_zip, String branch_phone, Timestamp last_updated) {
		super();
		this.branch_code = branch_code;
		this.branch_name = branch_name;
		this.branch_street = branch_street;
		this.branch_city = branch_city;
		this.branch_state = branch_state;
		this.branch_zip = branch_zip;
		this.branch_phone = branch_phone;
		this.last_updated = last_updated;
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

