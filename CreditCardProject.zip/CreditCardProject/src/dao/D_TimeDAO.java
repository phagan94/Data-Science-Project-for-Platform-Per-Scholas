package dao;

/**
 * @author Patrick Hagan
 * Date: September 5, 2018
 * Description: D_Time DAO Interface 
 */

import java.util.Set;

import model.D_Time;

public interface D_TimeDAO {
	public Set<D_Time> getAllD_Times();
	public D_Time  selectD_Time(String time_time_id);
	public boolean insertD_Time(D_Time d_time);
	public boolean updateD_Time(D_Time d_time);
	public boolean deleteD_Time(String time_time_id);

}
