/**
 * 
 */
package dao;

//import 
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.sql.Timestamp;

import model.Customer;

/**
* @author Patrick Hagan
* Date: September 5, 2018
* Description: Implementation of CustomerDAO  
*/
public class CustomerDAOImpl implements CustomerDAO {

	/**
	 * Do nothing constructor
	 */
	public CustomerDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	private Customer extractCustomerFromResultSet(ResultSet rs) throws SQLException {
	    Customer customer = new Customer();
	    customer.setFirst_name(rs.getString("first_name"));          
		customer.setMiddle_name(rs.getString("middle_name"));       
		customer.setLast_name(rs.getString("last_name"));             
		customer.setSsn(rs.getInt("ssn"));                       
		customer.setCredit_card_no(rs.getInt("credit_card_no"));  
		customer.setApt_no(rs.getString("apt_no"));                 
		customer.setStreet_name(rs.getString("street_name"));         
		customer.setCust_city(rs.getString("cust_city"));               
		customer.setCust_state(rs.getString("cust_state"));             
		customer.setCust_country(rs.getString("cust_country"));        
		customer.setCust_zip(rs.getString("cust_zip"));                 
		customer.setCust_phone(rs.getInt("cust_phone")); 
		customer.setCust_email(rs.getString("cust_email"));           
		customer.setLast_updated(rs.getTimestamp("last_updated"));
	    return customer;
	}
			
	/* (non-Javadoc)
	 * @see creditcardpackage.CustomerDAO#getAllCustomers()
	 */
	@Override
	public Set<Customer> getAllCustomers() {
		ConnectionFactory cf = new ConnectionFactory();
	    Connection connection = ConnectionFactory.getConnection();
	    try {
	        Statement stmt = connection.createStatement();
	        ResultSet rs = stmt.executeQuery("SELECT * FROM customer");
	        Set customers = new HashSet();
	        while(rs.next())
	        {
	            Customer customer = extractCustomerFromResultSet(rs);
	            customers.add(customer);
	        }
	        return customers;
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return null;
	}

	/* (non-Javadoc)
	 * @see creditcardpackage.CustomerDAO#selectCustomer(int, int)
	 */
	@Override
	public Customer selectCustomer(int ssn, int credit_card_no) {
		Connection connection = ConnectionFactory.getConnection();
	    try {
	        Statement stmt = connection.createStatement();
	        ResultSet rs = stmt.executeQuery("SELECT * FROM customer "
	        		+ "WHERE ssn = " + ssn
	        		+ "AND credit_card_no = " + credit_card_no);
	        if(rs.next())
	        {
	            return extractCustomerFromResultSet(rs);
	        }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return null;
	}

	/* (non-Javadoc)
	 * @see creditcardpackage.CustomerDAO#insertCustomer(creditcardpackage.Customer)
	 */
	@Override
	public boolean insertCustomer(Customer customer) {
		Connection connection = ConnectionFactory.getConnection();
	    try {
	        PreparedStatement ps = connection.prepareStatement("INSERT INTO customer "
	        		+ "VALUES (?, ?, ?, ?, ?, ?, ?, "
	        		+         "?, ?, ?, ?, ?, ?, ?)");
		    ps.setString   (1, customer.getFirst_name());          
		    ps.setString   (2, customer.getMiddle_name());       
		    ps.setString   (3, customer.getLast_name());             
		    ps.setInt      (4, customer.getSsn());                       
		    ps.setInt      (5, customer.getCredit_card_no());  
		    ps.setString   (6, customer.getApt_no());                 
		    ps.setString   (7, customer.getStreet_name());         
		    ps.setString   (8, customer.getCust_city());               
		    ps.setString   (9, customer.getCust_state());             
		    ps.setString   (10, customer.getCust_country());        
		    ps.setString   (11, customer.getCust_zip());                 
		    ps.setInt      (12, customer.getCust_phone()); 
		    ps.setString   (13, customer.getCust_email());           
		    ps.setTimestamp(14, customer.getLast_updated());
	        int i = ps.executeUpdate();
	        if(i == 1) {
	        	return true;
	        }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return false;
	}

	/* (non-Javadoc)
	 * @see creditcardpackage.CustomerDAO#updateCustomer(creditcardpackage.Customer)
	 */
	@Override
	public boolean updateCustomer(Customer customer) {
		Connection connection = ConnectionFactory.getConnection();
    	try {
    		PreparedStatement ps = connection.prepareStatement("UPDATE customer "
    			+ "SET first_name=? "          
    		    + "middle_name=? "
    		    + "last_name=? "     
    		    + "ssn=? "                       
    		    + "credit_card_no=? " 
    		    + "apt_no=? "                
    		    + "street_name=? "         
    		    + "cust_city=? "             
    		    + "cust_state=? "            
    		    + "cust_country=? "        
    		    + "cust_zip=? "                
    		    + "cust_phone=? "
    		    + "cust_email=? "           
    		    + "last_updated=? "
    		    + "WHERE ssn=? " 
        		+ "AND credit_card_no=? ");
    		ps.setString   (1, customer.getFirst_name());          
		    ps.setString   (2, customer.getMiddle_name());       
		    ps.setString   (3, customer.getLast_name());             
		    ps.setInt      (4, customer.getSsn());                       
		    ps.setInt      (5, customer.getCredit_card_no());  
		    ps.setString   (6, customer.getApt_no());                 
		    ps.setString   (7, customer.getStreet_name());         
		    ps.setString   (8, customer.getCust_city());               
		    ps.setString   (9, customer.getCust_state());             
		    ps.setString   (10, customer.getCust_country());        
		    ps.setString   (11, customer.getCust_zip());                 
		    ps.setInt      (12, customer.getCust_phone()); 
		    ps.setString   (13, customer.getCust_email());           
		    ps.setTimestamp(14, customer.getLast_updated());
		    ps.setInt      (15, customer.getSsn());                       
		    ps.setInt      (16, customer.getCredit_card_no());
    		int i = ps.executeUpdate();
    		if(i == 1) {
    			return true;
    		}
    	} catch (SQLException ex) {
    		ex.printStackTrace();
    	}
    	return false;
	}

	/* (non-Javadoc)
	 * @see creditcardpackage.CustomerDAO#deleteCustomer(int, int)
	 */
	@Override
	public boolean deleteCustomer(int ssn, int credit_card_no) {
		Connection connection = ConnectionFactory.getConnection();
    	try {
        	Statement stmt = connection.createStatement();
        	int i = stmt.executeUpdate("DELETE FROM customer "
        			+ "WHERE ssn = " + ssn
	        		+ "AND credit_card_no = " + credit_card_no);
        	if(i == 1) {
          		return true;
        	}
    	} catch (SQLException ex) {
        	ex.printStackTrace();
    	}
    	return false;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
