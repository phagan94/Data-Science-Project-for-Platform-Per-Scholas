/**
 * 
 */
package dao;
/**
 * @author Patrick Hagan
 * Date: September 5, 2018
 * Description: Customer DAO Interface 
 */

import java.sql.Timestamp;
import java.util.Set;

import model.Customer;

public interface CustomerDAO {
	public Set<Customer> getAllCustomers();
	public Customer selectCustomer(int ssn, int credit_card_no);
	public boolean  insertCustomer(Customer customer);
	public boolean  updateCustomer(Customer Customer);
	public boolean  deleteCustomer(int ssn, int credit_card_no);

}
