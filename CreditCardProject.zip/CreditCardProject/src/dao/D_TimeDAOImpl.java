/**
 * 
 */
package dao;

//import 
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

import model.D_Time;

/**
* @author Patrick Hagan
* Date: September 5, 2018
* Description: Implementation of TimeDAO  
*/
public class D_TimeDAOImpl implements D_TimeDAO {

	/**
	 * Do nothing constructor
	 */
	public D_TimeDAOImpl() {
		// TODO Auto-generated constructor stub
	}
	  
	private D_Time extractD_TimeFromResultSet(ResultSet rs) throws SQLException {
	    D_Time d_time = new D_Time();
	    d_time.setTime_time_id(rs.getString("time_time_id"));
	    d_time.setTime_day(rs.getInt("time_day")); 
	    d_time.setTime_month(rs.getInt("time_month"));
	    d_time.setTime_quarter(rs.getString("time_quarter"));    
	    d_time.setTime_year(rs.getInt("time_year"));         
	    return d_time;
	}
		
	/* (non-Javadoc)
	 * @see creditcardpackage.D_TimeDAO#getAllD_Times()
	 */
	@Override
	public Set<D_Time> getAllD_Times() {
		ConnectionFactory cf = new ConnectionFactory();
	    Connection connection = ConnectionFactory.getConnection();
	    try {
	        Statement stmt = connection.createStatement();
	        ResultSet rs = stmt.executeQuery("SELECT * FROM d_time");
	        Set d_times = new HashSet();
	        while(rs.next())
	        {
	            D_Time d_time = extractD_TimeFromResultSet(rs);
	            d_times.add(d_time);
	        }
	        return d_times;
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return null;
	}

	/* (non-Javadoc)
	 * @see creditcardpackage.D_TimeDAO#selectD_Time(java.lang.String)
	 */
	@Override
	public D_Time selectD_Time(String time_time_id) {
		 Connection connection = ConnectionFactory.getConnection();
		    try {
		        Statement stmt = connection.createStatement();
		        ResultSet rs = stmt.executeQuery("SELECT * FROM d_time WHERE time_time_id = " + time_time_id);
		        if(rs.next())
		        {
		            return extractD_TimeFromResultSet(rs);
		        }
		    } catch (SQLException ex) {
		        ex.printStackTrace();
		    }
		    return null;
	}

	/* (non-Javadoc)
	 * @see creditcardpackage.D_TimeDAO#insertD_Time(creditcardpackage.D_Time)
	 */
	@Override
	public boolean insertD_Time(D_Time d_time) {
		Connection connection = ConnectionFactory.getConnection();
	    try {
	        PreparedStatement ps = connection.prepareStatement("INSERT INTO user VALUES (?, ?, ?, ?, ?)");
	        ps.setInt    (1, d_time.getTime_day());     
		    ps.setInt    (2, d_time.getTime_month()); 
		    ps.setString (3, d_time.getTime_quarter()); 
		    ps.setInt    (4, d_time.getTime_year()); 
		    ps.setString (5, d_time.getTime_time_id());                  
			int i = ps.executeUpdate();
	        if(i == 1) {
	        	return true;
	        }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return false;
	}

	/* (non-Javadoc)
	 * @see creditcardpackage.D_TimeDAO#updateD_Time(creditcardpackage.D_Time)
	 */
	@Override
	public boolean updateD_Time(D_Time d_time) {
		Connection connection = ConnectionFactory.getConnection();
    	try {
    		PreparedStatement ps = connection.prepareStatement("UPDATE d_time "
    				+ "SET time_day=?, "
    				+ "time_month=?, "
    				+ "time_quarter=? "
    				+ "time_year=?, "
    				+ "time_time_id=?, "
    				+ "WHERE time_id=?");
    		ps.setInt    (1, d_time.getTime_day());     
		    ps.setInt    (2, d_time.getTime_month()); 
		    ps.setString (3, d_time.getTime_quarter()); 
		    ps.setInt    (4, d_time.getTime_year()); 
		    ps.setString (5, d_time.getTime_time_id()); 
		    ps.setString (6, d_time.getTime_time_id()); 
    		int i = ps.executeUpdate();
    		if(i == 1) {
    			return true;
    		}
    	} catch (SQLException ex) {
    		ex.printStackTrace();
    	}
    	return false;
	}

	/* (non-Javadoc)
	 * @see creditcardpackage.D_TimeDAO#deleteD_Time(java.lang.String)
	 */
	@Override
	public boolean deleteD_Time(String time_time_id) {
		Connection connection = ConnectionFactory.getConnection();
    	try {
        	Statement stmt = connection.createStatement();
        	int i = stmt.executeUpdate("DELETE FROM d_time WHERE time_time_id = " + time_time_id);
        	if(i == 1) {
          		return true;
        	}
    	} catch (SQLException ex) {
        	ex.printStackTrace();
    	}
    	return false;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
