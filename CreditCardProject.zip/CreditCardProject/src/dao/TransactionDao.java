package dao;

import java.io.IOException;
import java.sql.SQLException;

import model.transaction;
import resources.myQuries;

public class TransactionDao extends dbconnection_abstract {
 public transaction gettotalbyType(String type) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException, IOException
 {
	 myconnection();
	 ps = con.prepareStatement(myQuries.totaByType);
		ps.setString(1, type);
		rs = ps.executeQuery();
		transaction t = new transaction();
		if(rs.next())
		{
			t.setValue(rs.getInt(1));
			t.setCount(rs.getInt(2));
			//System.out.println(" Sum of values of all Transaction " + number);
			//System.out.println("Total Number of Tranaction: "+ transaction_type);
			return t;  }		return null;
 }}
