/**
 * 
 */
package dao;
/**
 * @author Patrick Hagan
 * Date: September 5, 2018
 * Description: Branch (Bank) DAO Interface 
 */
import java.util.Set;

import model.Branch;

public interface BranchDAO {
	public Set<Branch> getAllBranches();
	public Branch  selectBranch(int branch_code);
	public boolean insertBranch(Branch branch);
	public boolean updateBranch(Branch branch);
	public boolean deleteBranch(int branch_code);
}
