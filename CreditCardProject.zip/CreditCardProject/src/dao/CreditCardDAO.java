/**
 * 
 */
package dao;
/**
 * @author Patrick Hagan
 * Date: September 5, 2018
 * Description: CreditCard DAO Interface 
 */

import java.util.Set;

import model.CreditCard;

public interface CreditCardDAO {
	public Set<CreditCard> getAllCreditCards();
	public CreditCard selectCreditCard(int branch_code, int credit_card_no);
	public boolean insertCreditCard(CreditCard creditcard);
	public boolean updateCreditCard(CreditCard creditcard);
	public boolean deleteCreditCard(int branch_code, int credit_card_no);

}
