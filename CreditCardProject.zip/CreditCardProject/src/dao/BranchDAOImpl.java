/**
 * 
 */
package dao;

//import 
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

import model.Branch;

/**
 * @author Patrick Hagan
 * Date: September 5, 2018
 * Description: Implementation of BranchDAO  
 */

public class BranchDAOImpl implements BranchDAO {

	/**
	 * Do nothing constructor
	 */
	public BranchDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	private Branch extractBranchFromResultSet(ResultSet rs) throws SQLException {
	    Branch branch = new Branch();
	    branch.setBranch_code(rs.getInt("branch_code")); 
	    branch.setBranch_name(rs.getString("branch_name"));
	    branch.setBranch_street(rs.getString("branch_street"));    
	    branch.setBranch_city(rs.getString("branch_city"));         
	    branch.setBranch_state(rs.getString("branch_state"));       
	    branch.setBranch_zip(rs.getInt("branch_zip"));
	    branch.setBranch_phone(rs.getString("branch_phone"));    
	    branch.setLast_updated(rs.getTimestamp("last_updated"));
	    return branch;
	}
	
	/* (non-Javadoc)
	 * @see creditcardpackage.BranchDAO#getAllBranches()
	 */
	@Override
	public Set getAllBranches() {
	    ConnectionFactory cf = new ConnectionFactory();
	    Connection connection = ConnectionFactory.getConnection();
	    try {
	        Statement stmt = connection.createStatement();
	        ResultSet rs = stmt.executeQuery("SELECT * FROM branch");
	        Set branches = new HashSet();
	        while(rs.next())
	        {
	            Branch branch = extractBranchFromResultSet(rs);
	            branches.add(branch);
	        }
	        return branches;
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return null;
	}
	
	/* (non-Javadoc)
	 * @see creditcardpackage.BranchDAO#selectBranch()
	 */
	@Override
	public Branch selectBranch(int branch_code) {
	    Connection connection = ConnectionFactory.getConnection();
	    try {
	        Statement stmt = connection.createStatement();
	        ResultSet rs = stmt.executeQuery("SELECT * FROM branch WHERE branch_code = " + branch_code);
	        if(rs.next())
	        {
	            return extractBranchFromResultSet(rs);
	        }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return null;
	}
	
	/* (non-Javadoc)
	 * @see creditcardpackage.BranchDAO#insertBranch()
	 */
	@Override
	public boolean insertBranch(Branch branch) {
	    Connection connection = ConnectionFactory.getConnection();
	    try {
	        PreparedStatement ps = connection.prepareStatement("INSERT INTO user VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
	        ps.setInt      (1, branch.getBranch_code()); 
		    ps.setString   (2, branch.getBranch_name()); 
		    ps.setString   (3, branch.getBranch_street());    
		    ps.setString   (4, branch.getBranch_city());         
		    ps.setString   (5, branch.getBranch_state());       
		    ps.setInt      (6, branch.getBranch_zip()); 
		    ps.setString   (7, branch.getBranch_phone());  
		    ps.setTimestamp(8, branch.getLast_updated()); 
	        int i = ps.executeUpdate();
	        if(i == 1) {
	        	return true;
	        }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return false;
	}
	
	/* (non-Javadoc)
	 * @see creditcardpackage.BranchDAO#updateBranch()
	 */
	@Override
	public boolean updateBranch(Branch branch) {
    	Connection connection = ConnectionFactory.getConnection();
    	try {
    		PreparedStatement ps = connection.prepareStatement("UPDATE branch "
    				+ "SET branch_code=?, "
    				+ "branch_name=?, "
    				+ "branch_street=? "
    				+ "branch_city=?, "
    				+ "branch_state=?, "
    				+ "branch_zip=? "
    				+ "branch_phone=?, "
    				+ "branch_last_updated=?"
    				+ "WHERE branch_code=?");
    		ps.setInt      (1, branch.getBranch_code()); 
 		    ps.setString   (2, branch.getBranch_name()); 
 		    ps.setString   (3, branch.getBranch_street());    
 		    ps.setString   (4, branch.getBranch_city());         
 		    ps.setString   (5, branch.getBranch_state());       
 		    ps.setInt      (6, branch.getBranch_zip()); 
 		    ps.setString   (7, branch.getBranch_phone());  
 		    ps.setTimestamp(8, branch.getLast_updated()); 
 		    ps.setInt      (9, branch.getBranch_code()); 
    		int i = ps.executeUpdate();
    		if(i == 1) {
    			return true;
    		}
    	} catch (SQLException ex) {
    		ex.printStackTrace();
    	}
    	return false;
    }
  	
	/* (non-Javadoc)
	 * @see creditcardpackage.BranchDAO#deleteBranch()
	 */
	@Override
	public boolean deleteBranch(int branch_code) {
        Connection connection = ConnectionFactory.getConnection();
    	try {
        	Statement stmt = connection.createStatement();
        	int i = stmt.executeUpdate("DELETE FROM branch WHERE id=" + branch_code);
        	if(i == 1) {
          		return true;
        	}
    	} catch (SQLException ex) {
        	ex.printStackTrace();
    	}
    	return false;
	}
      	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
}

