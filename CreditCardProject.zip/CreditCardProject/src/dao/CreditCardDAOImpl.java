/**
 * 
 */
package dao;

//import 
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

import model.CreditCard;

/**
* @author Patrick Hagan
* Date: September 5, 2018
* Description: Implementation of CreditCardDAO  
*/
public class CreditCardDAOImpl implements CreditCardDAO {

	/**
	 * Do nothing constructor
	 */
	public CreditCardDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	private CreditCard extractCreditCardFromResultSet(ResultSet rs) throws SQLException {
	    CreditCard creditCard = new CreditCard();
	    creditCard.setTransaction_id(rs.getInt("transaction_id")); 
	    creditCard.setTday(rs.getInt("tday"));
	    creditCard.setTmonth(rs.getInt("tmonth"));    
	    creditCard.setCredit_card_no(rs.getInt("credit_card_no"));         
	    creditCard.setCust_ssn(rs.getInt("cust_ssn"));       
	    creditCard.setBranch_code(rs.getInt("branch_code"));
	    creditCard.setTransaction_type(rs.getString("transaction_type"));    
	    creditCard.setTransaction_value(rs.getDouble("transaction_value"));
	    return creditCard;
	}
	
	/* (non-Javadoc)
	 * @see creditcardpackage.CreditCardDAO#getAllCreditCards()
	 */
	@Override
	public Set<CreditCard> getAllCreditCards() {
		ConnectionFactory cf = new ConnectionFactory();
	    Connection connection = ConnectionFactory.getConnection();
	    try {
	        Statement stmt = connection.createStatement();
	        ResultSet rs = stmt.executeQuery("SELECT * FROM creditcard");
	        Set creditcards = new HashSet();
	        while(rs.next())
	        {
	            CreditCard creditcard = extractCreditCardFromResultSet(rs);
	            creditcards.add(creditcard);
	        }
	        return creditcards;
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return null;
	}

	/* (non-Javadoc)
	 * @see creditcardpackage.CreditCardDAO#selectCreditCard(int, int)
	 */
	@Override
	public CreditCard selectCreditCard(int branch_code, int credit_card_no) {
		Connection connection = ConnectionFactory.getConnection();
	    try {
	        Statement stmt = connection.createStatement();
	        ResultSet rs = stmt.executeQuery("SELECT * FROM creditcard "
	        		+ "WHERE transaction_id=? ");
	        if(rs.next())
	        {
	            return extractCreditCardFromResultSet(rs);
	        }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return null;
	}

	/* (non-Javadoc)
	 * @see creditcardpackage.CreditCardDAO#insertCreditCard(creditcardpackage.CreditCard)
	 */
	@Override
	public boolean insertCreditCard(CreditCard creditcard) {
		 Connection connection = ConnectionFactory.getConnection();
		    try {
		        PreparedStatement ps = connection.prepareStatement("INSERT INTO user VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
			    ps.setInt      (1, creditcard.getTransaction_id()); 
			    ps.setInt      (2, creditcard.getTday());
			    ps.setInt      (3, creditcard.getTmonth());    
			    ps.setInt      (4, creditcard.getCredit_card_no());         
			    ps.setInt      (5, creditcard.getCust_ssn());       
			    ps.setInt      (6, creditcard.getBranch_code());
			    ps.setString   (7, creditcard.getTransaction_type());    
			    ps.setDouble   (8, creditcard.getTransaction_value());
		        int i = ps.executeUpdate();
		        if(i == 1) {
		        	return true;
		        } 
		        else
		        {
		        	
		        }
		    } catch (SQLException ex) {
		        ex.printStackTrace();
		    }
		    return false;
	}

	/* (non-Javadoc)
	 * @see creditcardpackage.CreditCardDAO#updateCreditCard(creditcardpackage.CreditCard)
	 */
	@Override
	public boolean updateCreditCard(CreditCard creditcard) {
		Connection connection = ConnectionFactory.getConnection();
    	try {
    		PreparedStatement ps = connection.prepareStatement("UPDATE creditcard "
    				+ "SET transaction_id=?, "
    			    + "tday=?, "
    			    + "tmonth=?, "    
    			    + "credit_card_no=?, "         
    			    + "cust_ssn=?, "       
    			    + "branch_code=?, "
    			    + "transaction_type=?, "    
    			    + "transaction_value=?, "
    			   	+ "WHERE transaction_id=? ");
    		ps.setInt      (1, creditcard.getTransaction_id()); 
		    ps.setInt      (2, creditcard.getTday());
		    ps.setInt      (3, creditcard.getTmonth());    
		    ps.setInt      (4, creditcard.getCredit_card_no());         
		    ps.setInt      (5, creditcard.getCust_ssn());       
		    ps.setInt      (6, creditcard.getBranch_code());
		    ps.setString   (7, creditcard.getTransaction_type());    
		    ps.setDouble   (8, creditcard.getTransaction_value());
		    ps.setInt      (9, creditcard.getBranch_code());
		    ps.setInt      (10, creditcard.getCredit_card_no());
    		int i = ps.executeUpdate();
    		if(i == 1) {
    			return true;
    		}
    	} catch (SQLException ex) {
    		ex.printStackTrace();
    	}
    	return false;
	}

	/* (non-Javadoc)
	 * @see creditcardpackage.CreditCardDAO#deleteCreditCard(int, int)
	 */
	@Override
	public boolean deleteCreditCard(int branch_code, int credit_card_no) {
		Connection connection = ConnectionFactory.getConnection();
    	try {
        	Statement stmt = connection.createStatement();
        	int i = stmt.executeUpdate("DELETE FROM creditcard"
        			+ "WHERE branch_code = " + branch_code 
	        		+ "AND   creditcard_no = " + credit_card_no);
        	if(i == 1) {
          		return true;
        	}
    	} catch (SQLException ex) {
        	ex.printStackTrace();
    	}
    	return false;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
