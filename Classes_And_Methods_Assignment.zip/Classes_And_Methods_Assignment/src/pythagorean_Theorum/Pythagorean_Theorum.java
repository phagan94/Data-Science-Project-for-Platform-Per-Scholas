// Class Name: pythagorean_Theorum.java
// Package: Pythagorean_Theorum
// Author: Patrick Hagan
// Description: Calculates Pythagorean Theorum
// Date: July 25, 2018
// **********************************************************************************
// 4) Pythagorean Theorum
// Create a method that takes in two sides of a triangle  and returns the length of 
// the hypotenuse.
// This can be found with the following equation: c = sqrt(a^2 + b^2)
// Create a main that calls this method with at least 3 different sets of values and 
// prints the results of each.
// **********************************************************************************
package pythagorean_Theorum;

public class Pythagorean_Theorum {
    double side1 = 0;
    double side2 = 0;
    double side3 = 0;
    
	public double calculateLengthHypotenuse (double side1, double side2) {
		return (Math.sqrt(Math.pow(side1, 2) + Math.pow(side2, 2)));
	}
	
	public static void main(String[] args) {
		// create new instance of Pythagorean_Theorum class
		Pythagorean_Theorum pt = new Pythagorean_Theorum();
		
		// assign values to inputs and get the result
		pt.side1 = 10.0;
		pt.side2 = 20.0;
		pt.side3 = pt.calculateLengthHypotenuse(pt.side1, pt.side2);
		System.out.println("(1) The length of the hypotenuse for side1: " + pt.side1 +
				" and side2: " + pt.side2+ " is: " + pt.side3);
		
		pt.side1 = 33.3;
		pt.side2 = 222.22;
		pt.side3 = pt.calculateLengthHypotenuse(pt.side1, pt.side2);
		System.out.println("(2) The length of the hypotenuse for side1: " + pt.side1 +
				" and side2: " + pt.side2+ " is: " + pt.side3);
		
		pt.side1 = 24.24;
		pt.side2 = 44.44;
		pt.side3 = pt.calculateLengthHypotenuse(pt.side1, pt.side2);
		System.out.println("(3) The length of the hypotenuse for side1: " + pt.side1 +
				" and side2: " + pt.side2+ " is: " + pt.side3);

	}

}

