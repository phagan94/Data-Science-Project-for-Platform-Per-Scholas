// Class Name: students_Array.java
// Package: Students_Array
// Author: Patrick Hagan
// Description: Enters fixed number of students (3) as separate instances using an array
// Date: July 25, 2018
// *******************************************************************************************************
// 2) Getting more advanced
// Create an array of type Student with three positions.
// Read in their info just like before.
// Print out the names of those students, their grades, and their GPAs.Then, print out the average GPA of 
// all three students.
// *******************************************************************************************************
package students_Array;

import java.util.Scanner;
import students.Student;

public class Students_Array {
   
	public static void main(String[] args) {
		String studentName = " ";
		double studentGrade = 0.0;
		double studentGPA = 0.0;
		double totalGPA = 0.0;
		double averageGPA = 0.0;
       
        // create new empty student array	
		Student[] student = new Student[3];
             
		Scanner sc = new Scanner(System.in);
		
		for(int i = 0; i < 3; i++) {
			// enter name, grade, and GPA for new student
			System.out.println("Please enter the student name: ");
			studentName = sc.next();
						
			System.out.println("Please enter the student grade in double format 0.0: ");
			studentGrade = sc.nextDouble();
						
			System.out.println("Please enter the student gpa in double format 0.0: ");
			studentGPA = sc.nextDouble();
			
			student[i] = new Student(studentName, studentGrade, studentGPA);
			
			// keep track of total GPA for average GPA calculation
			totalGPA += studentGPA;

		}
		
		// close Scanner 
		sc.close();
		
		// print all the students entered
		for(int i = 0; i < 3; i++) {
			student[i].printStudent();
		}
		
		averageGPA = (totalGPA / 3.0);
		System.out.println("Total: " + totalGPA + " The average GPA of all three students is: " + averageGPA);

	}

}

