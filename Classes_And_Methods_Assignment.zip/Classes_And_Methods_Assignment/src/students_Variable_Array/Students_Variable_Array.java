// Class Name: students_Variable_Array.java
// Package: Students_Variable_Array
// Author: Patrick Hagan
// Description: Enters variable number of students as separate instances as part of variable array
// Date: July 25, 2018
// *******************************************************************************************************
// 3) Now we're talking
// Ask the user to input the number of students they would like to enter. Store this in an integer 
// named [numStudents].
// Create an array of type Student with [numStudents] positions.
// Read through their info via a loop.
// Using a loop, print out the names of those students, their grades, and their GPAs. Finally, print out 
// the average GPA of all students.
// ******************************************************************************************************
package students_Variable_Array;

import java.util.Scanner;
import students.Student;

public class Students_Variable_Array {
		
	public static void main(String[] args) {
		int numStudents = 0;
	    String studentName = " ";
		double studentGrade = 0.0;
		double studentGPA = 0.0;
		double totalGPA = 0.0;
		double averageGPA = 0.0;
		int counter = 0;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter the number of students you would like to enter: ");
		numStudents = sc.nextInt();
		
		// create new empty student array	
		Student[] student = new Student[numStudents];
		
		for(int i = 0; i < numStudents; i++) {
			// enter name, grade, and GPA for new student
			System.out.println("Please enter the student name: ");
			studentName = sc.next();
						
			System.out.println("Please enter the student grade in double format 0.0: ");
			studentGrade = sc.nextDouble();
			
			System.out.println("Please enter the student gpa in double format 0.0: ");
			studentGPA = sc.nextDouble();
			
			// add name, grade, and gpa to new student instance 
			student[i] = new Student(studentName, studentGrade, studentGPA);
			
			// keep track of total GPA for average GPA calculation
			totalGPA += studentGPA;

			// add 1 to counter to keep track of the number of students entered
			counter++;
		}
		
		// close Scanner
		sc.close();
		
		// print all the students entered
		for(int i = 0; i < counter; i++) {
			student[i].printStudent();
		}
		
		averageGPA = (totalGPA / counter);
		System.out.println("The average GPA of all " + counter + " students is: " + averageGPA);
	
	}

}

