// Class Name: students_Fixed.java
// Package: Students_Fixed
// Author: Patrick Hagan
// Description: Enters fixed number of students (3) as separate instances
// Date: July 25, 2018
// ********************************************************************************S
package students_Fixed;

import java.util.*;
import students.Student;

public class Students_Fixed {

	public static void main(String[] args) {
		String studentName = " ";
		double studentGrade = 0.0;
		double studentGPA = 0.0;
		double averageGPA = 0.0;
		Scanner sc = new Scanner(System.in);
		
		Student student1 = new Student();
		System.out.println("Please enter the student1 name: ");
		studentName = sc.next();
		student1.setName(studentName);
		System.out.println("Please enter the student1 grade in double format 0.0: ");
		studentGrade = sc.nextDouble();
		student1.setGrade(studentGrade);
		System.out.println("Please enter the student1 gpa in double format 0.0: ");
		studentGPA = sc.nextDouble();
		student1.setGPA(studentGPA);
		
		Student student2 = new Student();
		System.out.println("Please enter the student2 name: ");
		studentName = sc.next();
		student2.setName(studentName);
		System.out.println("Please enter the student2 grade in double format 0.0: ");
		studentGrade = sc.nextDouble();
		student2.setGrade(studentGrade);
		System.out.println("Please enter the student2 gpa in double format 0.0: ");
		studentGPA = sc.nextDouble();
		student2.setGPA(studentGPA);
		
		Student student3 = new Student();
		System.out.println("Please enter the student3 name: ");
		studentName = sc.next();
		student3.setName(studentName);
		System.out.println("Please enter the student3 grade in double format 0.0: ");
		studentGrade = sc.nextDouble();
		student3.setGrade(studentGrade);
		System.out.println("Please enter the student3 gpa in double format 0.0: ");
		studentGPA = sc.nextDouble();
		student3.setGPA(studentGPA);
		
		sc.close();
		
		System.out.println("The first student\'s name is: " + student1.getName() + 
				" with a grade of: " + student1.getGrade() + 
				" and a GPA of: " + student1.getGPA());
		
		System.out.println("The second student\'s name is: " + student2.getName() + 
				" with a grade of: " + student2.getGrade() + 
				" and a GPA of: " + student2.getGPA());
		
		System.out.println("The third student\'s name is: " + student3.getName() + 
				" with a grade of: " + student3.getGrade() + 
				" and a GPA of: " + student3.getGPA());
		
		averageGPA = (((student1.getGPA() + student2.getGPA() + student3.getGPA()) / 3.0));
		System.out.println("The average GPA of all three students is: " + averageGPA);
		
		student1.printStudent();
		student2.printStudent();
		student3.printStudent();
		
	}

}

