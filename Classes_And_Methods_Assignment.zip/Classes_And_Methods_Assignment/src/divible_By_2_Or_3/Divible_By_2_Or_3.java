// Class Name: Divible_By_2_Or_3.java
// Package: divible_By_2_Or_3
// Author: Patrick Hagan
// Description: Indicate whther number is divisible by 2 with <, by 3 with =, both <= 
// Date: July 25, 2018
// *******************************************************************************************************
// 6) Divisible by...
// Create two functions:
// public static boolean isEven( int n ) The function should return the value true if n is an even number 
// (divisible by 2) and false otherwise.
// And
// public static boolean isDivisibleBy3( int n ) The function should return the value true if n is evenly 
// divisible by 3 and false otherwise.
// Write a main() that contains a for loop to generate all the numbers from 1 to 20. Use if statements  
// inside the loop to mark the number with a "<" if it's even, with a "=" if it's evenly divisible by 3,  
// and with both if it's divisible by both 2 and 3.
// For example, numbers 1-5 would look like this: 
// 1
//  2 <
//  3 =
//  4 <
// 5
// 6 <=
// *****************************************************************************************************
package divible_By_2_Or_3;

public class Divible_By_2_Or_3 {
	
	public static boolean isEvent(int n) {
		return ((n % 2 == 0) ? true : false); 
	}

	public static boolean isDivisibleBy3(int n) {
		return ((n % 3 == 0) ? true : false); 
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean result1 = false;
		boolean result2 = false;
		String displayValue1 = " ";  
		String displayValue2 = " ";
        for (int i = 1; i < 21; i++) {
        	result1 = isEvent(i);
        	result2 = isDivisibleBy3(i);
        	if ((result1 == true) && (result2 == true)) {
        		displayValue1 = "<";
        		displayValue2 = "=";
        	}
        	
        	if ((result1 == true) && (result2 == false)) {
        		displayValue1 = "<";
        		displayValue2 = " ";
        	}
        	
        	if ((result1 == false) && (result2 == true)) {
        		displayValue1 = "=";
        		displayValue2 = " ";
        	}
        	
        	if ((result1 == false) && (result2 == false)) {
        		displayValue1 = " ";
        		displayValue2 = " ";
        	}
        	
        	System.out.println(i + " " + displayValue1  + displayValue2);
        }
	}

}

