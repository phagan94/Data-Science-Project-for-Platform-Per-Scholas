// Class Name: Area_Calculator.java
// Package: area_Calculator
// Author: Patrick Hagan
// Description: Calculates area of a circle, rectangle, square, triangle
// Date: July 25, 2018
// *******************************************************************************************************
// 5) Area Calculator
// Create four methods to calculate te area for different objects.
// Your method declaration will look something like this:
// returns the area of a circle
// public static double area_circle()   
// returns the area of a circle
// returns the area of a rectangle
// public static int area_rectangle()   
// returns the area of a square
// public static int area_square()      
// returns the area of a triangle
// public static double area_triangle() 
// The equations for each are as follows:
// Circle = pi * radius^2
// Rectangle = length * width
// Square = side^2
// Triangle = 0.5 * base * height
// Note: you can use Math.PI for the value of pi.
// *******************************************************************************************************
package area_Calculator;

import java.util.Scanner;

public class Area_Calculator {

	static double radius = 0.0;
	static double length = 0.0;
	static double width = 0.0;
	static double side = 0.0;
	static double base = 0.0;
	static double height = 0.0;
	int select = 0;
    
    // returns the area of a circle  
	public static double area_circle() {
		return (Math.PI * Math.pow(Area_Calculator.radius, 2));
	}
    
    // returns the area of a rectangle 
	public static double area_rectangle() {
	 	 return (Area_Calculator.length * Area_Calculator.width);
	}
	 
	// returns the area of a square 
	public static double area_square() {
		return (Math.pow(Area_Calculator.side, 2));
	} 

    // returns the area of a triangle 
	public static double area_triangle() {
		 return (0.5 * Area_Calculator.base * Area_Calculator.height);
	} 

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Area_Calculator ac = new Area_Calculator();
		System.out.println("Please enter 1 for circle, 2 for rectangle, 3 for square, and 4 for triangle: ");
		ac.select = sc.nextInt();
		
		switch (ac.select) {
		case 1:
			System.out.println("Please enter the radius for your circle calculation: ");
			Area_Calculator.radius = sc.nextDouble();
			System.out.println("The area of your circle is: " + Area_Calculator.area_circle());
			break;
		case 2:
			System.out.println("Please enter the length for your rectangle calculation: ");
			Area_Calculator.length = sc.nextDouble();
			System.out.println("Please enter the width for your rectangle calculation: ");
			Area_Calculator.width = sc.nextDouble();
			System.out.println("The area of your rectangle is: " + Area_Calculator.area_rectangle());
			break;
		case 3:
			System.out.println("Please enter the side for your square calculation: ");
			Area_Calculator.side = sc.nextDouble();
			System.out.println("The area of your square is: " + Area_Calculator.area_square());
			break;
		case 4:
			System.out.println("Please enter the base for your triangle calculation: ");
			Area_Calculator.base = sc.nextDouble();
			System.out.println("Please enter the height for your triangle calculation: ");
			Area_Calculator.height = sc.nextDouble();
			Area_Calculator.area_triangle();
			System.out.println("The area of your triangle is: " + Area_Calculator.area_triangle());
			break;
		default:
			System.out.println("You entered the wrong selection. " + " Please start over and " +
					"only enter 1 for circle, 2 for rectangle, 3 for square, and 4 for triangle: ");
		}
		sc.close();
	}

}

