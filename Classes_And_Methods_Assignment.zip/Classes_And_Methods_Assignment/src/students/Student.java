// Class Name: Student.java
// Package: students
// Author: Patrick Hagan
// Description: Student class with name, grade, and gpa
// Date: July 25, 2018
// *******************************************************************************************************
// 1) Students
// Create a Student class to store information about a student. This includes a Name, a Grade, and a GPA.
// Create three instances of type Student. Read the values for those students from user input.
// Print out the names of those students, their grades, and their GPAs. Then, print out the average GPA of 
// all three students.
// *******************************************************************************************************
package students;

public class Student {
	
	String name = " ";
	double grade = 0.00;
	double gpa = 0.00;
	
	public String getName() {
		return this.name;
	}
	
	public double getGrade() {
		return this.grade;
	}
	
	public double getGPA() {
		return this.gpa;
	}
	
	public void setName(String valueName) {
		this.name = valueName;
	}
	
	public void setGrade(double valueGrade) {
		this.grade = valueGrade;
	}
	
	public void setGPA(double valueGPA) {
		this.gpa = valueGPA;
	}
	
	public void printStudent() {
	System.out.println("The student\'s name is: " + this.getName() + 
			" with a grade of: " + this.getGrade() + 
			" and a GPA of: " + this.getGPA());
	}
	
	public Student (String name, double grade, double gpa) {
		this.name = name;
		this.grade = grade;
		this.gpa = gpa;
	}
	
	public Student () {
		
	}
}