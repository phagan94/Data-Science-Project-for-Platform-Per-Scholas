// Class Name: sumOfColumn.java
// Package: SumOfColumn
// Author: Patrick Hagan
// Description: Select column to get the sum of that column
// Date: July 24, 2018
// *******************************************************************************************************
package SumOfColumn;

import  java.util.*;

public class sumOfColumn {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int array1 [] [] = {{10, 3, 5}, {8, 2, 4}, {6, 9, 8}};
		int colSel = 0;
		int intSel = 0;
		int colSum1 = 0;
		int colSum2 = 0;
		
		// print original integer array and ask for column to sum
		for(int i=0; i < array1.length; i++){
		   for(int j=0; j < array1.length; j++){
       	      System.out.print(array1 [i][j] + "\t"); 
		   }   
		   System.out.println(" ");
		}
			 
		sumOfColumn soc = new sumOfColumn();
		// entering integers 1-3 rather than 0-2 to make it easy on user
		System.out.println("Please enter an Integer (1-3) for column to sum:");
		
		Scanner sc = new Scanner(System.in); 
		colSel = sc.nextInt();
				
		// convert 1-3 values to array indexes 0-2 
		if(colSel == 1 || colSel == 2 || colSel == 3) {
           intSel = colSel - 1; 
           colSum1 = array1 [0] [intSel] + array1 [1] [intSel] + array1 [2] [intSel];
           System.out.println("The first sum of the column: " + colSel +
        		   " is the value: " + colSum1); 
          
           for(int i=0; i < array1.length; i++){
        	  colSum2 += array1 [i] [intSel];
           }
           System.out.println("The second sum of the column: " + colSel +
        		   " is the value: " + colSum2); 
		}
		else {
		   System.out.println("Error: You did not enter an Integer between 1 and 3 for column to sum:");
		}
	}

}
