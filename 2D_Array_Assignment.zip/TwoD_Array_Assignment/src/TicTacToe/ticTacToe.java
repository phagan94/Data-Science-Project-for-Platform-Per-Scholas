// Class Name: ticTacToe.java
// Package: TicTacToe
// Author: Patrick Hagan
// Description: Plays a simple game of Tic Tac Toe
// Date: July 24, 2018
// *******************************************************************************************************
package TicTacToe;

import  java.util.*;

public class ticTacToe {
	
	// I originally used spaces, but you cannot see them on the board
	char array1 [] [] = {{'_', '_', '_'}, {'_', '_', '_'}, {'_', '_', '_'}};
	char arrayTracker [] [] = {{'_', '_', '_'}, {'_', '_', '_'}, {'_', '_', '_'}};
				
	int userRowSel = 0;
	int realIntRow = 0;
	int userColSel = 0;
	int realIntCol = 0;
	int turn = 0;
	int elements = 9;
	int savei = 0;
							
	char playerX = 'X';
	char playerY = 'Y';
	char playerTurn = ' ';
	char flagFound = 'N';
	Scanner sc = new Scanner(System.in);
	
	public void printArray(char[][] array1) {
		int intRealCol = 0;
		// print original integer array and ask for column to sum
		System.out.println("Row" + "\t" + "Column" + "\t" +  "1" + "\t" + "2" + "\t" + "3");
		for(int i=0; i < array1.length; i++){
			intRealCol = i + 1;
			System.out.print(intRealCol + "\t\t"); 
			for(int j=0; j < array1.length; j++){
				System.out.print(array1 [i][j] + "\t"); 
			}   
			System.out.println(" ");
		}
	}
	
	public int executeTurn(char playerTurn, char flagFound, int savei) {
		System.out.println("Player " + playerTurn + " Please enter an Integer (1-3) for row choice ");
		//entering integers 1-3 rather than 0-2 to make it easy on user
		userRowSel = sc.nextInt();
		// convert row 1-3 values to array indexes 0-2 
		if(userRowSel == 1 || userRowSel == 2 || userRowSel == 3) {
			realIntRow = userRowSel - 1; 
		}
		
		System.out.println("Player " + playerTurn + " Please enter an Integer (1-3) for column choice ");
		// entering integers 1-3 rather than 0-2 to make it easy on user
		userColSel = sc.nextInt();
		// convert column 1-3 values to array indexes 0-2 
		if(userColSel == 1 || userColSel == 2 || userColSel == 3) {
			realIntCol = userColSel - 1; 
		}
		
		System.out.println("Player " + playerTurn + " realIntRow: " + realIntRow + " realIntCol: " + realIntCol + 
				" userRowSel: " + userRowSel + " userColSel: " + userColSel);
		
		if (arrayTracker [realIntRow] [realIntCol] == '_') {
			arrayTracker [realIntRow] [realIntCol] = playerTurn;
		    flagFound = 'Y';
    	} 
		else
		{	
			System.out.println("Your row and column choice has already been choosen.");
			System.out.println("Please select another row and column.");
			savei--;
		}
		
		return savei;
	}
	
	public static void main(String[] args) {
		ticTacToe ttt = new ticTacToe();
		ttt.printArray(ttt.array1);
			
		// cannot use array1.length because it is only 3 so used hard-coded elements = 9
		for(int i=0; i < ttt.elements; i++){
			ttt.turn = i;
			if (ttt.turn %2 == 0) {
				ttt.playerTurn = ttt.playerY;
				ttt.flagFound = 'N';
				System.out.println("playerY i before): " + i);
				do {
					ttt.savei = ttt.executeTurn(ttt.playerTurn, ttt.flagFound, i);
				} while (ttt.flagFound == 'Y');
				i = ttt.savei;
				System.out.println("playerY i after): " + i);
				ttt.array1 [ttt.realIntRow] [ttt.realIntCol] = ttt.playerTurn;
				ttt.printArray(ttt.array1);
			} 
			else 
			{	
				ttt.playerTurn = ttt.playerX;			
				ttt.flagFound = 'N';
				System.out.println("playerX i before): " + i);
				do {
					ttt.savei = ttt.executeTurn(ttt.playerTurn, ttt.flagFound, i);
				} while (ttt.flagFound == 'Y');
				i = ttt.savei;
				System.out.println("playerX i after): " + i);
				ttt.array1 [ttt.realIntRow] [ttt.realIntCol] = ttt.playerTurn;
				ttt.printArray(ttt.array1);
			}
		}
		
		System.out.println("Game is over. Here is the final result.");
		ttt.printArray(ttt.array1);
	}	 
}

	
		
